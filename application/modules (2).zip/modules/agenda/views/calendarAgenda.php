<section class="panel">
    <header class="panel-heading">
        Agenda Kegiatan Ketua Umum
        <span class="tools pull-right">
            <a href="javascript:;" class="fa fa-chevron-down"></a>
            <a href="javascript:;" class="fa fa-cog"></a>
            <a href="javascript:;" class="fa fa-times"></a>
        </span>
    </header>
    <div class="panel-body">
        <!-- page start-->
        <div class="row">
            <aside class="col-lg-1">
                
                <div id="external-events">
                </div>
            </aside>
            <aside class="col-lg-10 center">
                <div id="calendar" class="has-toolbar fc"></div>
            </aside>
            <aside class="col-lg-1">
                
                <div id="external-events">
                </div>
            </aside>
        </div>
        <!-- page end-->
    </div>
</section>