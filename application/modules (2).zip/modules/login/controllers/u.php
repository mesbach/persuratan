<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');
/**
 * Description of login
 *
 * @author andremaulana
 */
class u extends Login_Controller {

    function __construct() {
        parent::__construct();
        $this->load->driver('session');
        $this->load->helper(array('url'));
        $this->load->model('user/model_user');
    }
 
    public function index() {
        $this->title="Login Page";
        $this->display('login');
    }
    function cekLogin() {
        if (isset($this->session->userdata['logged_in'])) {
            $data = $this->session->userdata['logged_in'];
            if (count($data) > 0) {
                return true;
            }
        }
        return false;
    }

    function registration() {
        $this->template->set_layout('blank');
        $this->template->title("Register Page");
        $this->template->build("register.php");
    }

    function submitregister() {
        $data['nama'] = $this->input->post('nama');
        $data['alamat'] = $this->input->post('alamat');
        $data['telp'] = $this->input->post('telp');
        $data['email'] = $this->input->post('email');
        $data['gender'] = $this->input->post('gender');
        $data['username'] = $this->input->post('username');
        $data['password'] = $this->input->post('password');
        $res = $this->model_user->register($data);
        if ($res != 0) {
            redirect("user/u/login");
        }
    }

    function logout() {
        $this->session->sess_destroy();
        redirect('/');
    }

    function login() {
        if (!$this->cekLogin()) {
            $menu = "hf/menu/menu_umum.php";
            $footer = "hf/footer/footer.php";
            $this->template->set_layout('fe');
            $this->template->title("Home Admin");
            $this->template->set_partial("menu", $menu);
            $this->template->set_partial("footer", $footer);
            $this->template->build("login.php");
        } else {
            redirect("pengaduan/" . $this->session->userdata['logged_in']['privilege']);
        }
    }

    function signin() {
        if (!$this->cekLogin()) {
            $data['username'] = $this->input->post('username');
            $data['password'] = $this->input->post('password');
            $result = $this->model_user->login($data['username'], $data['password']);
            $session_arr = array();
            $url = "";
            if ($result != null) {
                if ($result[0]->idadmin > 0) {
                    $url = "index.php/dashboard/coord";
                    $session_arr = array("privilege" => "s", "id" => $result[0]->idadmin, "nama" => $result[0]->nama);
                } else if ($result[0]->idadmin == 0) {
                    $url = "index.php/dashboard/coord";
                    $session_arr = array("privilege" => "s", "id" => $result[0]->idadmin, "nama" => $result[0]->nama);
                }
                $this->session->set_userdata("logged_in", $session_arr);
            }
            if (count($result) == 0) {
                $this->template->set_layout('template');
                $this->template->title("Login Page");
                $message['error'] = "Username atau Password anda tidak benar";
                $this->template->build("login.php", $message);
                $this->login();
            } else {
                redirect($url);
            }
        } else {
            redirect("index.php/dashboard/coord");
        }
    }

}
