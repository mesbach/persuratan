<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

//inbox
class Coord extends Koordinator_Controller {
    
    public function __construct() {
        parent::__construct();
        $this->load->model('dashboard/model');
    }
    
    //inbox
    public function index() {
        
        $this->display('inbox');
    }
    
    //inbox
    public function inbox() {
        $this->title="Surat Masuk";
        $this->script_header = 'lay-scripts/header_mail_kks';
        $this->script_footer = 'lay-scripts/footer_mail_kks';
        $this->menuMail = 'other/menuMailCoord';
        $this->display('inbox');
    }
    
    //outbox
    public function outbox() {
        $this->title="Surat Keluar";
        $this->script_header = 'lay-scripts/header_mail_kks';
        $this->script_footer = 'lay-scripts/footer_mail_kks';
        $this->menuMail = 'other/menuMailCoord';
        $this->display('outbox');
    }
    
    //list draft
    public function draft() {
        $this->title="Draft Surat";
        $this->script_header = 'lay-scripts/header_mail_kks';
        $this->script_footer = 'lay-scripts/footer_mail_kks';
        $this->menuMail = 'other/menuMailCoord';
        $this->display('draft');
    }
    
    //lihat detil draft surat. 
    //draftInView untuk surat masuk
    //draftOutView untuk surat keluar
    public function draftView() {
        $this->title="Draft Surat";
        $this->script_header = 'lay-scripts/header_mail_kks';
        $this->script_footer = 'lay-scripts/footer_mail_kks';
        $this->menuMail = 'other/menuMailCoord';
        //if draft surat masuk
        $this->display('draftInView');
        //else if draft surat keluar
        //$this->display('draftOutView');
    }
    
    //lihat detil surat masuk
    public function viewMail($id) {
        $data['surat'] = $this->model->getMail($id);
        $this->model->readMail($id);
        $this->title="Detil Surat";
        $this->script_header = 'lay-scripts/header_mail_kks';
        $this->script_footer = 'lay-scripts/footer_mail_kks';
        $this->menuMail = 'other/menuMailCoord';
        $this->display('viewMail',$data);
    }
    
    //lihat detil surat keluar
    public function viewOutMail() {
        $this->title="Detil Surat Keluar";
        $this->script_header = 'lay-scripts/header_mail_kks';
        $this->script_footer = 'lay-scripts/footer_mail_kks';
        $this->menuMail = 'other/menuMailCoord';
        $this->display('viewOutMail');
    }
    
    //form pencarian surat
    public function search() {
        $this->title="Pencarian Arsip";
        $this->script_header = 'lay-scripts/header_mail_kks';
        $this->script_footer = 'lay-scripts/footer_mail_kks';
        $this->menuMail = 'other/menuMailCoord';
        $this->display('search');
    }
    
    //hasil pencarian
    public function searchresult() {
        $this->title="Pencarian Arsip";
        $this->script_header = 'lay-scripts/header_mail_kks';
        $this->script_footer = 'lay-scripts/footer_mail_kks';
        $this->menuMail = 'other/menuMailCoord';
        $this->display('searchresult');
    }
    public function newMail(){
        $data['jurnal'] = $this->input->post('jurnal');
        $data['nomor'] = $this->input->post('nomor');
        $data['tanggal_surat'] = $this->calendar($this->input->post('tanggal_surat'));
        $data['perihal'] = $this->input->post('perihal');
        $data['sifat'] = $this->input->post('mendesak')."|".$this->input->post('rahasia')."|".$this->input->post('penting')."|".$this->input->post('biasa');
        $data['pengirim'] = $this->input->post('pengirim');
        $data['penerima'] = $this->input->post('penerima');
        $data['tanggal_terima'] = $this->calendar ($this->input->post('tanggal_terima'));
        $data['kategori'] = $this->input->post('kategori');
        $data['tembusan'] = $this->input->post('tembusan');
        $data['jenis_surat'] = "in";
        $data['isi'] = $this->input->post('isi');
        $this->db->insert("surat",$data);
        redirect('mail/coord/inbox');
    }
    public function newOutMail(){
        $data['jurnal'] = $this->input->post('jurnal');
        $data['nomor'] = $this->input->post('nomor');
        $data['tanggal_surat'] = $this->calendar($this->input->post('tanggal_surat'));
        $data['perihal'] = $this->input->post('perihal');
        $data['sifat'] = $this->input->post('mendesak')."|".$this->input->post('rahasia')."|".$this->input->post('penting')."|".$this->input->post('biasa');
        $data['pengirim'] = $this->input->post('pengirim');
        $data['penerima'] = $this->input->post('penerima');
        $data['tanggal_terima'] = $this->calendar ($this->input->post('tanggal_terima'));
        $data['kategori'] = $this->input->post('kategori');
        $data['tembusan'] = $this->input->post('tembusan');
        $data['jenis_surat'] = "out";
        $data['isi'] = $this->input->post('isi');
        $this->db->insert("surat",$data);
        redirect('mail/coord/outbox');
    }
    private function calendar($tanggal)
    {
        $date = explode('-', $tanggal);
        return $date[2]."-".$date[0].'-'.$date[1];
    }
}